﻿namespace ustaRestaurant.Data.Static
{
    public class UserRoles
    {
        public const string Admin = "admin";
        public const string User = "user";
    }
}
