﻿using ustaRestaurant.Data.Base;
using ustaRestaurant.Models;


namespace ustaRestaurant.Data.Services
{
    public interface IProductTypeService:IEntityBaseRepository<ProductType>
    {
  
    }
}
