﻿using ustaRestaurant.Models;
using ustaRestaurant.Data.Base;

namespace ustaRestaurant.Data.Services
{
    public interface IDeliveryService:IEntityBaseRepository<Delivery>
    {


    }
}
