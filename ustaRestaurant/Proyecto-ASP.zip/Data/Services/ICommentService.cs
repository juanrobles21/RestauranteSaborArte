﻿using ustaRestaurant.Data.Base;
using ustaRestaurant.Models;

namespace ustaRestaurant.Data.Services
{
    public interface ICommentService : IEntityBaseRepository<Comment>
    {
    }
}
