﻿namespace ustaRestaurant.Data.Enum
{
    public enum QualityProduct
    {
        Pesimo=1,
        Malo=2,
        Regular=3,
        Bueno=4,
        Excelente=5
    }
}
